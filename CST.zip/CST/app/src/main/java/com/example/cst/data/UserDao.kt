package com.example.cst.data

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.Query
import kotlin.jvm.JvmSuppressWildcards

@Dao
@JvmSuppressWildcards   // ✅ THIS FIXES THE ERROR
interface UserDao {

    @Insert
    suspend fun register(user: User): Long

    @Query("SELECT * FROM users WHERE email = :email AND password = :password")
    suspend fun login(email: String, password: String): User?

    @Query("SELECT * FROM users WHERE email = :email LIMIT 1")
    suspend fun getByEmail(email: String): User?

}